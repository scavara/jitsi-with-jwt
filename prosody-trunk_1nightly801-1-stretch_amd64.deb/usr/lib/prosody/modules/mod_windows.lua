-- Windows platform stub
module:set_global();

-- TODO Add Windows-specific things here
